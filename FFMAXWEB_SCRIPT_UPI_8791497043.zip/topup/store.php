<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from new.offersales.shop/users/sprit/store.php by HTTrack Website Copier/3.x [XR&CO'2017], Sun, 30 Aug 2026 08:52:57 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="description" content="Free Fire top-up store — diamonds, Booyah Pass, memberships and more." />
  <title>Store — Official Top Up Center</title>
  <link rel="icon" type="image/png" href="garena.png" />
  <link rel="apple-touch-icon" href="garena.png" />
  <link rel="preconnect" href="../../../external.html?link=https://fonts.googleapis.com/" />
  <link rel="preconnect" href="../../../external.html?link=https://fonts.gstatic.com/" crossorigin />
  <link href="../../../external.html?link=https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&amp;family=Russo+One&amp;display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="css/styles.css" />
  
  <!-- ============================================================
       🔥 DISCOUNT CONFIGURATION - YAHAN CHANGE KARO 🔥
       ============================================================ -->
  <script>
  // Har product ka alag discount (percent)
  const PRODUCT_DISCOUNTS = {
    'p1': 5,
    'p2': 10,
    'p3': 12,
    'p4': 15,
    'p5': 18,
    'p7': 8,
    'p8': 10,
    'p16': 7,
    'p17': 12
  };
  </script>
  
  <script>
  try{if(localStorage.getItem('ff_theme')==='dark')document.documentElement.classList.add('dark');}catch(e){}
  </script>
</head>
<body>
  <div class="bg-orbs" aria-hidden="true">
    <span class="orb orb-1"></span>
    <span class="orb orb-2"></span>
    <span class="orb orb-3"></span>
  </div>

  <!-- Header -->
  <header class="site-header" id="header">
    <div class="container header-inner">
      <a href="index.php" class="brand">
        <img src="garena.png" alt="Garena" class="brand-logo" />
        <span class="brand-text">
          <strong>Official Top Up</strong>
          <small>Center</small>
        </span>
      </a>
      <nav class="main-nav" id="mainNav">
        <a href="index.php">Home</a>
        <a href="index.php#how">How it works</a>
        <a href="index.php#faq">FAQ</a>
      </nav>
      <button class="theme-toggle" id="themeToggle" aria-label="Toggle dark mode" title="Toggle theme">🌙</button>
      <button class="nav-toggle" id="navToggle" aria-label="Toggle menu">
        <span></span><span></span><span></span>
      </button>
    </div>
  </header>

  <!-- Verified account bar -->
  <section class="store-hero">
    <div class="container">
      <div class="verified-bar">
        <div class="vb-left">
          <div class="vb-avatar"><img src="g/icon.png" alt="Free Fire" /></div>
          <div class="vb-info">
            <span class="vb-label">Topping up for</span>
            <strong id="vNick">—</strong>
            <span class="vb-meta">UID <b id="vUid">—</b> · <span id="vLevel">—</span></span>
          </div>
          <span class="vb-badge">✓ Verified</span>
        </div>
        <a href="#" id="changeAccount" class="vb-change">Change account</a>
      </div>
    </div>
  </section>

  <!-- Store -->
  <section class="products" id="products">
    <div class="container">
      <div class="section-head">
        <h2>Top Up <span class="grad">Centre</span></h2>
        <p>Pick a pack — delivered instantly to your verified account.</p>
      </div>

      <div class="tabs" id="tabs" role="tablist"><!-- injected by JS --></div>

      <div class="product-grid" id="productGrid"><!-- injected by JS --></div>
    </div>
  </section>

  <!-- Footer -->
  <footer class="footer">
    <div class="container footer-inner">
      <div>
        <a href="index.php" class="brand brand-footer">
          <img src="garena.png" alt="Garena" class="brand-logo" />
          <span class="brand-text"><strong>Official Top Up</strong><small>Center</small></span>
        </a>
        <p class="muted">Genuine Free Fire top-ups, delivered instantly to your UID.</p>
      </div>
      <div class="footer-cols">
        <div><h4>Store</h4><a href="#products">Diamonds</a><a href="#products">Booyah Pass</a><a href="#products">Membership</a></div>
        <div><h4>Help</h4><a href="index.php#faq">FAQ</a><a href="index.php#how">How it works</a><a href="index.php">Home</a></div>
        <div><h4>Legal</h4><a href="#">Terms</a><a href="#">Privacy</a><a href="#">Refunds</a></div>
      </div>
    </div>
    <div class="container copyright">© <span id="year"></span> FireTopUp. All rights reserved.</div>
  </footer>

  <!-- Payment Modal (UPI QR + auto-verify) -->
  <div class="modal-overlay" id="payOverlay" hidden>
    <div class="modal modal-pay" role="dialog" aria-modal="true">
      <button class="modal-close" id="payClose" aria-label="Close">✕</button>
      <div class="modal-body" id="payBody"><!-- injected by JS --></div>
    </div>
  </div>

  <!-- Toast -->
  <div class="toast" id="toast" hidden></div>

  <script src="js/data.js"></script>
  <script src="../../../cdn.jsdelivr.net/npm/%40twemoji/api%4015.1.0/dist/twemoji.min.js" crossorigin="anonymous"></script>
  <script src="js/app0d05.js"></script>
</body>

<!-- Mirrored from new.offersales.shop/users/sprit/store.php by HTTrack Website Copier/3.x [XR&CO'2017], Sun, 30 Aug 2026 08:53:04 GMT -->
</html>
