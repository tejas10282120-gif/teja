<?php
// Central configuration for the FFMAXWEB application.
// All admin/store settings are read from /admin/data/config.json.

function config_file(): string { return __DIR__.'/admin/data/config.json'; }
function store_file(): string { return __DIR__.'/admin/data/store.json'; }

const DEFAULT_MERCHANT_UPI = 'test@fam';
const DEFAULT_MERCHANT_NAME = 'Garena Diamond Store';
const DEFAULT_ADMIN_USERNAME = 'dark';
const DEFAULT_ADMIN_PASSWORD = 'webs';
const ORDER_TTL = 600;
const ADMIN_SESSION_KEY = 'ffmax_admin_auth';
const STORE_FILE = __DIR__.'/admin/data/store.json';
const CONFIG_FILE = __DIR__.'/admin/data/config.json';

function secure_load(): array {
    $defaults = [
        'merchant_upi' => DEFAULT_MERCHANT_UPI,
        'merchant_name' => DEFAULT_MERCHANT_NAME,
        'admin_username' => DEFAULT_ADMIN_USERNAME,
        'admin_password_hash' => password_hash(DEFAULT_ADMIN_PASSWORD, PASSWORD_DEFAULT),
    ];
    if (!is_file(CONFIG_FILE)) {
        secure_save($defaults);
        return $defaults;
    }
    $raw = @file_get_contents(CONFIG_FILE);
    $cfg = json_decode($raw ?: '', true);
    if (!is_array($cfg)) $cfg = [];
    $cfg = array_merge($defaults, $cfg);
    if (empty($cfg['admin_username'])) $cfg['admin_username'] = DEFAULT_ADMIN_USERNAME;
    if (empty($cfg['admin_password_hash'])) $cfg['admin_password_hash'] = $defaults['admin_password_hash'];
    return $cfg;
}

function secure_save(array $cfg): void {
    $dir = dirname(CONFIG_FILE);
    if (!is_dir($dir)) @mkdir($dir, 0750, true);
    $tmp = $dir.'/config.json.tmp.'.bin2hex(random_bytes(4));
    $json = json_encode($cfg, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
    if ($json === false || @file_put_contents($tmp, $json, LOCK_EX) === false) {
        @unlink($tmp);
        throw new RuntimeException('Unable to save configuration.');
    }
    @chmod($tmp, 0600);
    if (!@rename($tmp, CONFIG_FILE)) { @unlink($tmp); throw new RuntimeException('Unable to replace configuration.'); }
    @chmod(CONFIG_FILE, 0600);
}

function store_load(): array {
    if (!is_file(STORE_FILE)) return ['products'=>[], 'orders'=>[]];
    $raw = @file_get_contents(STORE_FILE);
    $d = json_decode($raw ?: '', true);
    return is_array($d) ? $d : ['products'=>[], 'orders'=>[]];
}
function store_save(array $d): void {
    $dir = dirname(STORE_FILE);
    if (!is_dir($dir)) @mkdir($dir,0750,true);
    $tmp=$dir.'/store.json.tmp.'.bin2hex(random_bytes(4));
    $json=json_encode($d,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
    if($json===false || @file_put_contents($tmp,$json,LOCK_EX)===false){@unlink($tmp);throw new RuntimeException('Unable to save store.');}
    @chmod($tmp,0600);
    if(!@rename($tmp,STORE_FILE)){@unlink($tmp);throw new RuntimeException('Unable to replace store.');}
    @chmod(STORE_FILE,0600);
}
function input_json(): array {
    $raw=file_get_contents('php://input');
    $x=json_decode($raw ?: '', true);
    return is_array($x)?$x:[];
}
function clean(string $v,int $max=255): string {
    $v=trim($v);
    if(function_exists('mb_substr')) return mb_substr($v,0,$max,'UTF-8');
    return substr($v,0,$max);
}
function json_response(array $data,int $status=200): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    echo json_encode($data,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
    exit;
}
function admin_required(): void {
    if(session_status()!==PHP_SESSION_ACTIVE){
        session_set_cookie_params(['httponly'=>true,'secure'=>!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off','samesite'=>'Lax']);
        session_start();
    }
    if(empty($_SESSION[ADMIN_SESSION_KEY])) json_response(['ok'=>false,'error'=>'Admin authentication required.'],401);
}
