<?php
require __DIR__.'/../config.php';
admin_required();
$cfg=secure_load();
$d=store_load();
$a=$_GET['action']??'';

if($a==='list') json_response(['ok'=>true,'orders'=>array_reverse($d['orders']??[])]);
if($a==='settings' && $_SERVER['REQUEST_METHOD']==='GET') json_response(['ok'=>true,'settings'=>[
    'merchant_upi'=>$cfg['merchant_upi']??DEFAULT_MERCHANT_UPI,
    'merchant_name'=>$cfg['merchant_name']??DEFAULT_MERCHANT_NAME,
    'admin_username'=>$cfg['admin_username']??DEFAULT_ADMIN_USERNAME,
]]);
if($a==='merchant_upi' && $_SERVER['REQUEST_METHOD']==='POST'){
    $x=input_json();
    $upi=clean((string)($x['merchant_upi']??''),100);
    if(!preg_match('/^[^@\s]+@[^@\s]+$/',$upi)) json_response(['ok'=>false,'error'=>'Please enter a valid merchant UPI ID.'],400);
    $cfg['merchant_upi']=$upi;
    secure_save($cfg);
    json_response(['ok'=>true,'merchant_upi'=>$upi]);
}
if($a==='merchant_name' && $_SERVER['REQUEST_METHOD']==='POST'){
    $x=input_json();
    $name=clean((string)($x['merchant_name']??''),100);
    if($name==='') json_response(['ok'=>false,'error'=>'Please enter a merchant name.'],400);
    $cfg['merchant_name']=$name;
    secure_save($cfg);
    json_response(['ok'=>true,'merchant_name'=>$name]);
}
if($a==='username' && $_SERVER['REQUEST_METHOD']==='POST'){
    $x=input_json(); $username=clean((string)($x['admin_username']??''),40);
    if(!preg_match('/^[A-Za-z0-9._-]{3,40}$/',$username)) json_response(['ok'=>false,'error'=>'Admin username must be 3–40 letters, numbers, dot, underscore or hyphen.'],400);
    $cfg['admin_username']=$username;
    // Preserve the existing password hash exactly as stored in config.json.
    secure_save($cfg);
    json_response(['ok'=>true,'admin_username'=>$username]);
}
if($a==='password' && $_SERVER['REQUEST_METHOD']==='POST'){
    $x=input_json(); $pw=(string)($x['password']??'');
    if(strlen($pw)<6) json_response(['ok'=>false,'error'=>'Password must be at least 6 characters.'],400);
    $cfg['admin_password_hash']=password_hash($pw,PASSWORD_DEFAULT);
    secure_save($cfg);
    json_response(['ok'=>true]);
}

function product_dir(): string { $dir=__DIR__.'/../uploads/products'; if(!is_dir($dir)) @mkdir($dir,0755,true); return $dir; }
function category_slug(string $s): string { return in_array($s,['diamonds','passes'],true)?$s:''; }
function product_catalog(array &$d): array { if(!isset($d['products'])||!is_array($d['products'])) $d['products']=[]; return $d['products']; }
function image_path_allowed(string $rel): bool { return (bool)preg_match('#^uploads/products/[A-Za-z0-9._-]+\.(png|jpe?g|webp|gif)$#i',$rel); }
function remove_product_image(string $rel): void { if(!image_path_allowed($rel)) return; $full=__DIR__.'/../'.str_replace(['../','\\'],['','/'],$rel); if(is_file($full)) @unlink($full); }

if($a==='products' && $_SERVER['REQUEST_METHOD']==='GET'){
    json_response(['ok'=>true,'categories'=>$d['products']??[]]);
}
if($a==='save_product' && $_SERVER['REQUEST_METHOD']==='POST'){
    $x=input_json(); $cat=category_slug(clean((string)($x['category']??''),20));
    if(!$cat) json_response(['ok'=>false,'error'=>'Choose Diamonds or Passes.'],400);
    $id=clean((string)($x['id']??''),50);
    $name=clean((string)($x['name']??''),100); $amount=clean((string)($x['amount']??''),80); $sub=clean((string)($x['sub']??''),120);
    $price=(float)($x['price']??0); $old=(float)($x['old']??0); $stock=max(0,(int)($x['stock']??0));
    $tag=clean((string)($x['tag']??''),20); if(!in_array($tag,['','hot','best','new'],true)) $tag='';
    $icon=clean((string)($x['icon']??'💎'),10); $image=clean((string)($x['image']??''),220);
    if($name===''||$price<0||$old<0||$amount==='') json_response(['ok'=>false,'error'=>'Name, amount and valid prices are required.'],400);
    if($image && !image_path_allowed($image)) $image='';
    $found=false;
    foreach($d['products'] as &$c) if(($c['slug']??'')===$cat) {
        foreach(($c['items']??[]) as &$p) if($id!=='' && ($p['id']??'')===$id) {
            if($image==='' && !empty($p['image'])) $image=$p['image'];
            $p=array_merge($p,['id'=>$id,'icon'=>$icon,'image'=>$image,'amount'=>$amount,'name'=>$name,'sub'=>$sub,'price'=>$price,'old'=>$old,'tag'=>$tag?:null,'stock'=>$stock,'inStock'=>$stock>0,'updated_at'=>time()]); $found=true; break;
        } unset($p);
        if(!$found){
            $id=$id!==''?$id:'p_'.bin2hex(random_bytes(5));
            $c['items'][]=['id'=>$id,'icon'=>$icon,'image'=>$image,'amount'=>$amount,'name'=>$name,'sub'=>$sub,'price'=>$price,'old'=>$old,'tag'=>$tag?:null,'stock'=>$stock,'inStock'=>$stock>0]; $found=true;
        }
        break;
    } unset($c);
    if(!$found) json_response(['ok'=>false,'error'=>'Category not found.'],404);
    store_save($d); json_response(['ok'=>true,'product_id'=>$id,'categories'=>$d['products']]);
}
if($a==='delete_product' && $_SERVER['REQUEST_METHOD']==='POST'){
    $x=input_json(); $cat=category_slug(clean((string)($x['category']??''),20)); $id=clean((string)($x['id']??''),50);
    if(!$cat||!$id) json_response(['ok'=>false,'error'=>'Invalid product.'],400);
    foreach($d['products'] as &$c) if(($c['slug']??'')===$cat) {
        foreach(($c['items']??[]) as $i=>$p) if(($p['id']??'')===$id){ if(!empty($p['image'])) remove_product_image($p['image']); array_splice($c['items'],$i,1); store_save($d); json_response(['ok'=>true]); }
    } unset($c);
    json_response(['ok'=>false,'error'=>'Product not found.'],404);
}
if($a==='upload_product_image' && $_SERVER['REQUEST_METHOD']==='POST'){
    if(empty($_FILES['image'])||!is_uploaded_file($_FILES['image']['tmp_name'])) json_response(['ok'=>false,'error'=>'Choose an image.'],400);
    $f=$_FILES['image']; if($f['error']!==UPLOAD_ERR_OK || $f['size']>5*1024*1024) json_response(['ok'=>false,'error'=>'Image must be under 5 MB.'],400);
    $info=@getimagesize($f['tmp_name']); if(!$info) json_response(['ok'=>false,'error'=>'Only real image files are allowed.'],400);
    $mime=$info['mime']??''; $ext=['image/png'=>'png','image/jpeg'=>'jpg','image/webp'=>'webp','image/gif'=>'gif'][$mime]??''; if(!$ext) json_response(['ok'=>false,'error'=>'Use PNG, JPG, WEBP or GIF.'],400);
    $name='products_'.date('YmdHis').'_'.bin2hex(random_bytes(4)).'.'.$ext; $dest=product_dir().'/'.$name;
    if(!move_uploaded_file($f['tmp_name'],$dest)) json_response(['ok'=>false,'error'=>'Upload failed.'],500); @chmod($dest,0644);
    $newRel='uploads/products/'.$name;
    // When editing an existing product, bind the new image immediately so
    // Upload/Replace works even if the admin forgets a second Save click.
    $cat=category_slug(clean((string)($_POST['category']??''),20));
    $pid=clean((string)($_POST['product_id']??''),50);
    if($cat && $pid){
        foreach($d['products'] as &$c) if(($c['slug']??'')===$cat){
            foreach(($c['items']??[]) as &$p) if(($p['id']??'')===$pid){
                $old=(string)($p['image']??''); $p['image']=$newRel;
                $p['updated_at']=time();
                store_save($d);
                if($old && $old!==$newRel) remove_product_image($old);
                break 2;
            } unset($p);
        } unset($c);
    }
    json_response(['ok'=>true,'image'=>$newRel,'categories'=>$d['products']??[]]);
}
if($a==='list_images' && $_SERVER['REQUEST_METHOD']==='GET'){
    $files=[]; foreach(glob(product_dir().'/*')?:[] as $f) if(is_file($f) && preg_match('/\.(png|jpe?g|webp|gif)$/i',$f)) $files[]='uploads/products/'.basename($f);
    json_response(['ok'=>true,'images'=>$files]);
}
if($a==='delete_image' && $_SERVER['REQUEST_METHOD']==='POST'){
    $x=input_json(); $rel=clean((string)($x['image']??''),220); if(!$rel||!image_path_allowed($rel)) json_response(['ok'=>false,'error'=>'Invalid image.'],400);
    remove_product_image($rel);
    foreach($d['products']??[] as &$c) foreach($c['items']??[] as &$p) if(($p['image']??'')===$rel) $p['image']='';
    unset($c,$p); store_save($d); json_response(['ok'=>true]);
}

if($a==='verify_utr' && $_SERVER['REQUEST_METHOD']==='POST'){
    $x=input_json(); $id=(int)($x['id']??0); $d=store_load();
    foreach($d['orders'] as &$o) if((int)($o['id']??0)===$id){
        if(empty($o['utr'])) json_response(['ok'=>false,'error'=>'No UTR submitted for this order.'],400);
        $o['status']='paid'; $o['paid_at']=time(); $o['updated_at']=time(); store_save($d); json_response(['ok'=>true]);
    } unset($o); json_response(['ok'=>false,'error'=>'Order not found'],404);
}
if($a==='status' && $_SERVER['REQUEST_METHOD']==='POST'){
    $x=input_json(); $id=(int)($x['id']??0); $status=clean((string)($x['status']??''),20); $delivery=clean((string)($x['delivery_status']??''),20);
    if(!in_array($status,['pending','claimed','paid','expired','cancelled'],true)||!in_array($delivery,['pending','processing','delivered','failed'],true)) json_response(['ok'=>false,'error'=>'Invalid status'],400);
    foreach($d['orders'] as &$o) if((int)$o['id']===$id){$o['status']=$status;$o['delivery_status']=$delivery;if($status==='paid'&&!$o['paid_at'])$o['paid_at']=time();$o['updated_at']=time();} unset($o);
    store_save($d); json_response(['ok'=>true]);
}
json_response(['ok'=>false,'error'=>'Unknown action'],404);
