/* Product catalogue. Edit freely — prices in INR (₹). */
window.PRODUCTS = {
    diamonds: [{
        id: 'd1',
        icon: '💎',
        amount: '100',
        name: '100 Diamonds',
        sub: '+10 bonus',
        price: 80,
        old: 90,
        tag: null
    }, {
        id: 'd2',
        icon: '💎',
        amount: '310',
        name: '310 Diamonds',
        sub: '+31 bonus',
        price: 240,
        old: 260,
        tag: null
    }, {
        id: 'd3',
        icon: '💎',
        amount: '520',
        name: '520 Diamonds',
        sub: '+52 bonus',
        price: 400,
        old: 440,
        tag: 'hot'
    }, {
        id: 'd4',
        icon: '💎',
        amount: '1060',
        name: '1060 Diamonds',
        sub: '+106 bonus',
        price: 790,
        old: 860,
        tag: null
    }, {
        id: 'd5',
        icon: '💎',
        amount: '2180',
        name: '2180 Diamonds',
        sub: '+218 bonus',
        price: 1580,
        old: 1700,
        tag: 'best'
    }, {
        id: 'd6',
        icon: '💎',
        amount: '5600',
        name: '5600 Diamonds',
        sub: '+560 bonus',
        price: 3900,
        old: 4300,
        tag: null
    }, ],
    passes: [{
        id: 'p1',
        icon: '🎟️',
        amount: 'Booyah',
        name: 'Booyah Pass',
        sub: 'Current season — premium',
        price: 399,
        old: 499,
        tag: 'hot'
    }, {
        id: 'p2',
        icon: '👑',
        amount: 'Booyah+',
        name: 'Booyah Pass Plus',
        sub: 'Premium + 30 level jump',
        price: 899,
        old: 999,
        tag: 'best'
    }, {
        id: 'p3',
        icon: '⬆️',
        amount: 'Level',
        name: 'Level Up Pass',
        sub: 'Unlock seasonal rewards',
        price: 149,
        old: 199,
        tag: null
    }, {
        id: 'p4',
        icon: '🎯',
        amount: 'Weekly',
        name: 'Weekly Lite Pass',
        sub: '7-day rewards track',
        price: 99,
        old: 129,
        tag: null
    }, ],
    membership: [{
        id: 'm1',
        icon: '📅',
        amount: 'Weekly',
        name: 'Weekly Membership',
        sub: 'Daily diamonds for 7 days',
        price: 149,
        old: 179,
        tag: null
    }, {
        id: 'm2',
        icon: '🗓️',
        amount: 'Monthly',
        name: 'Monthly Membership',
        sub: 'Daily diamonds for 30 days',
        price: 799,
        old: 899,
        tag: 'best'
    }, ],
    special: [{
        id: 's1',
        icon: '🎁',
        amount: 'Bundle',
        name: 'Evo Gun Bundle',
        sub: 'Limited cosmetic bundle',
        price: 599,
        old: 799,
        tag: 'hot'
    }, {
        id: 's2',
        icon: '🔫',
        amount: 'Skin',
        name: 'Weapon Royale Spin',
        sub: '10x luck royale spins',
        price: 299,
        old: 359,
        tag: null
    }, {
        id: 's3',
        icon: '🧥',
        amount: 'Bundle',
        name: 'Mystery Outfit Box',
        sub: 'Random legendary outfit',
        price: 249,
        old: 299,
        tag: null
    }, ],
};