/* ============================================================
   FireTopUp — front-end logic (multi-page)
   ------------------------------------------------------------
   Pages:
     index.html  → landing + UID verification
     store.html  → store (only reachable after UID is verified)

   👉 ONLY THING YOU NEED TO SWAP WHEN YOUR REAL API ARRIVES:
      the fetchPlayerInfo() function below.
   ============================================================ */

const CONFIG = {
    // Set USE_MOCK = true to test without hitting the live API.
    USE_MOCK: false,

    // Live Free Fire player-info endpoint. {UID} is replaced with the entered UID.
    // This API sends CORS headers (Access-Control-Allow-Origin: *), so the browser
    // can call it directly — no server-side proxy needed.
    API_URL: 'https://s.xysushi.in/ff/?uid={UID}',

    // Extra request headers (none required for this API).
    API_HEADERS: {},

    CURRENCY: '₹',
};

/* ------------------------------------------------------------
   API: fetch the player's info by UID.
   Resolves to: { nickname, uid, level, region, likes, clan, elitePass }
   Throws an Error if the UID is invalid / not found.

   The API responds with HTTP 200 even for bad UIDs, returning
   { status: "error", ... } with no `basicinfo` — so we detect that.
   ------------------------------------------------------------ */
async function fetchPlayerInfo(uid) {
    if (CONFIG.USE_MOCK) return mockPlayerInfo(uid);
    return await fetchPlayerFrom(CONFIG.API_URL, uid);
}

/* Fetch + normalise a single endpoint. Throws on failure, returns a player. */
async function fetchPlayerFrom(urlTemplate, uid) {
    const url = urlTemplate.replace('{UID}', encodeURIComponent(uid));
    let res;
    try {
        res = await fetch(url, {
            headers: CONFIG.API_HEADERS
        });
    } catch (_) {
        throw new Error('Network error — please check your connection and try again.');
    }
    if (!res.ok) throw new Error('UID not found. Please check your UID and try again.');

    let data;
    try {
        data = await res.json();
    } catch (_) {
        throw new Error('UID not found. Please check your UID and try again.');
    }

    const player = normalizePlayer(data, uid);
    if (!player) throw new Error('UID not found. Please check your UID and try again.');
    return player;
}

/* First non-empty value among the given keys of an object. */
function pickField(obj, keys) {
    if (!obj || typeof obj !== 'object') return undefined;
    for (const k of keys) {
        const v = obj[k];
        if (v !== undefined && v !== null && v !== '') return v;
    }
    return undefined;
}

/* Map various Free Fire API response shapes to our player object. Returns null
   if no usable nickname is found (treated as "not found"). */
function normalizePlayer(data, uid) {
    if (!data || typeof data !== 'object') return null;

    const d = data.data && typeof data.data === 'object' ? data.data : data;
    // Where the player fields usually live across the common API formats.
    const info = data.basicinfo || data.basicInfo || d.basicInfo || d.basicinfo ||
        d.AccountInfo || d.account || d.profile || d.player || d;
    const clan = data.clanbasicinfo || data.clanBasicInfo || d.clanBasicInfo ||
        d.ClanInfo || d.clan || {};

    const nickname = pickField(info, ['nickname', 'name', 'AccountName', 'username', 'nick']) ||
        pickField(data, ['nickname', 'name', 'AccountName']);
    if (!nickname) return null;

    const accountId = pickField(info, ['accountid', 'accountId', 'AccountId', 'uid', 'id', 'AccountUID']) ||
        pickField(data, ['accountid', 'accountId', 'uid', 'id']);
    const level = pickField(info, ['level', 'AccountLevel', 'lvl']);
    const region = pickField(info, ['region', 'AccountRegion', 'Region']);
    const liked = pickField(info, ['liked', 'likes', 'AccountLikes', 'like']);
    const elite = pickField(info, ['haselitepass', 'hasElitePass', 'elitePass', 'ElitePass']);
    const clanName = pickField(clan, ['clanname', 'clanName', 'ClanName', 'name']);

    return {
        nickname: String(nickname),
        uid: accountId != null ? String(accountId) : String(uid),
        level: level != null ? level : '—',
        region: region || '—',
        likes: typeof liked === 'number' ? liked : (liked != null && !isNaN(+liked) ? +liked : null),
        clan: clanName ? String(clanName).trim() : null,
        elitePass: !!elite,
    };
}

/* Mock used until the real API is wired in. Generates believable data. */
function mockPlayerInfo(uid) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (!/^\d{6,12}$/.test(uid)) {
                reject(new Error('UID not found. Make sure it is 6–12 digits.'));
                return;
            }
            const names = ['ShadowSlayer', 'BooyahKing', 'PhantomX', 'GhostRider', 'NoScopeRaj', 'DesiGamerz', 'ProBunny', 'IcyBlaze', 'VortexFF', 'LegendAryan'];
            const regions = ['IND', 'SG', 'BR', 'ID', 'ME'];
            const seed = [...uid].reduce((a, c) => a + (+c), 0);
            resolve({
                nickname: names[seed % names.length] + (seed % 97),
                uid,
                level: 20 + (seed % 60),
                region: regions[seed % regions.length],
            });
        }, 1100); // simulate network
    });
}

/* ============================================================
   Helpers
   ============================================================ */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const money = (n) => `${CONFIG.CURRENCY}${n.toLocaleString('en-IN')}`;

/* Verified player is shared across pages via sessionStorage */
const PLAYER_KEY = 'ff_player';
const savePlayer = (p) => {
    try {
        sessionStorage.setItem(PLAYER_KEY, JSON.stringify(p));
    } catch (_) {}
};
const loadPlayer = () => {
    try {
        return JSON.parse(sessionStorage.getItem(PLAYER_KEY));
    } catch (_) {
        return null;
    }
};
const clearPlayer = () => {
    try {
        sessionStorage.removeItem(PLAYER_KEY);
    } catch (_) {}
};

const state = {
    player: loadPlayer(),
    currentCat: 'diamonds',
    selected: null
};

/* Replace OS emoji with crisp premium Twemoji stickers */
function premiumEmoji(el = document.body) {
    if (window.twemoji) {
        twemoji.parse(el, {
            folder: 'svg',
            ext: '.svg',
            base: 'https://cdn.jsdelivr.net/gh/jdecked/twemoji@15.1.0/assets/',
        });
    }
}

function toast(msg, type = '') {
    const t = $('#toast');
    if (!t) return;
    t.textContent = msg;
    t.className = `toast ${type}`;
    t.hidden = false;
    requestAnimationFrame(() => t.classList.add('show'));
    clearTimeout(toast._t);
    toast._t = setTimeout(() => {
        t.classList.remove('show');
        setTimeout(() => (t.hidden = true), 300);
    }, 3200);
}

function findProduct(id) {
    return Object.values(window.PRODUCTS).flat().find(p => p.id === id);
}

/* ============================================================
   Modal helpers
   ============================================================ */
function openModal(el) {
    if (!el) return;
    el.hidden = false;
    document.body.style.overflow = 'hidden';
}

function closeModal(el) {
    if (!el) return;
    el.hidden = true;
    document.body.style.overflow = '';
}

function initModals() {
    $$('.modal-overlay').forEach(ov =>
        ov.addEventListener('click', (e) => {
            if (e.target === ov) closeModal(ov);
        })
    );
    window.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') $$('.modal-overlay').forEach(closeModal);
    });
}

/* ============================================================
   Dark / light theme toggle (persisted)
   ============================================================ */
function initTheme() {
    const btn = $('#themeToggle');
    if (!btn) return;
    const root = document.documentElement;
    const setIcon = () => {
        btn.textContent = root.classList.contains('dark') ? '☀️' : '🌙';
    };
    setIcon();
    btn.addEventListener('click', () => {
        root.classList.toggle('dark');
        try {
            localStorage.setItem('ff_theme', root.classList.contains('dark') ? 'dark' : 'light');
        } catch (_) {}
        setIcon();
    });
}

/* ============================================================
   Header nav (mobile menu)
   ============================================================ */
function initNav() {
    const navToggle = $('#navToggle');
    const mainNav = $('#mainNav');
    if (!navToggle || !mainNav) return;

    navToggle.addEventListener('click', () => {
        mainNav.classList.toggle('open');
        navToggle.classList.toggle('open');
    });
    $$('.main-nav a').forEach(a => a.addEventListener('click', () => {
        mainNav.classList.remove('open');
        navToggle.classList.remove('open');
    }));
    $$('[data-scroll]').forEach(b =>
        b.addEventListener('click', () => $(b.dataset.scroll)?.scrollIntoView({
            behavior: 'smooth'
        }))
    );
}

/* ============================================================
   Reveal on scroll
   ============================================================ */
const io = new IntersectionObserver((entries) => {
    entries.forEach(e => {
        if (e.isIntersecting) {
            e.target.classList.add('in');
            io.unobserve(e.target);
        }
    });
}, {
    threshold: 0.15
});

function initReveal() {
    $$('.section-head, .step, .uid-card, .acc-item').forEach(el => {
        el.classList.add('reveal');
        io.observe(el);
    });
}

/* ============================================================
   Fake purchase popups (social proof)
   ============================================================ */
function initSalePops() {
    // Mostly boys' names, a few girls'.
    const names = ['Rahul', 'Aman', 'Arjun', 'Karan', 'Rohit', 'Vikram', 'Sahil', 'Aditya', 'Dev', 'Kabir',
        'Ishaan', 'Sanjay', 'Aryan', 'Rohan', 'Akash', 'Manish', 'Nikhil', 'Yash', 'Harsh', 'Raj',
        'Ankit', 'Varun', 'Siddharth', 'Gaurav', 'Priya', 'Sneha', 'Neha', 'Ananya', 'Riya'
    ];
    const states = ['Delhi', 'Maharashtra', 'Uttar Pradesh', 'Karnataka', 'Tamil Nadu', 'West Bengal',
        'Gujarat', 'Rajasthan', 'Punjab', 'Bihar', 'Madhya Pradesh', 'Haryana', 'Kerala',
        'Telangana', 'Andhra Pradesh', 'Assam', 'Odisha', 'Jharkhand', 'Chhattisgarh', 'Goa'
    ];
    const rand = (a) => a[Math.floor(Math.random() * a.length)];
    // Start with the static fallback; replaced by the real catalogue once loaded.
    let products = Object.values(window.PRODUCTS || {}).flat();

    // Pull the live catalogue so popups use the actual uploaded product images.
    fetch(API_BASE + 'products.php', {
            cache: 'no-store'
        })
        .then(r => r.json())
        .then(d => {
            if (d && d.ok && Array.isArray(d.categories)) {
                const items = d.categories.flatMap(c => c.items || []);
                if (items.length) products = items;
            }
        }).catch(() => {});

    const pop = document.createElement('div');
    pop.className = 'sale-pop';
    pop.hidden = true;
    document.body.appendChild(pop);

    const scheduleNext = () => setTimeout(show, 6000); // each new popup 6s apart

    function show() {
        // Don't show while a payment modal is open — it would overlap the QR.
        const pay = document.getElementById('payOverlay');
        if (pay && !pay.hidden) {
            scheduleNext();
            return;
        }
        if (!products.length) {
            scheduleNext();
            return;
        }

        const p = rand(products);
        const mins = 1 + Math.floor(Math.random() * 12);
        const icon = p.image ? `<img src="${esc(p.image)}?v=${encodeURIComponent(String(p.updated_at||p.image))}" alt="">` : (p.icon || '🎮');
        pop.innerHTML = `
      <div class="sp-icon">${icon}</div>
      <div class="sp-body">
        <strong>${rand(names)} <span class="sp-state">from ${rand(states)}</span></strong>
        <span>just bought <b>${esc(p.name)}</b></span>
        <small><i class="sp-dot"></i>${mins} min ago · Verified ✓</small>
      </div>`;
        premiumEmoji(pop);
        pop.hidden = false;
        requestAnimationFrame(() => pop.classList.add('show'));
        setTimeout(hide, 4000);
    }

    function hide() {
        pop.classList.remove('show');
        setTimeout(() => {
            pop.hidden = true;
        }, 500);
        scheduleNext();
    }

    setTimeout(show, 6000);
}

/* ============================================================
   Banner carousel — auto-slide every 4s  (landing only)
   ============================================================ */
function initCarousel() {
    const track = $('#carouselTrack');
    if (!track) return;
    const slides = $$('.slide', track);
    const dotsWrap = $('#carouselDots');
    const total = slides.length;
    let index = 0,
        timer = null;
    const INTERVAL = 4000;

    dotsWrap.innerHTML = slides.map((_, i) =>
        `<button role="tab" aria-label="Go to slide ${i + 1}"${i === 0 ? ' class="active"' : ''}></button>`
    ).join('');
    const dots = $$('button', dotsWrap);

    function go(i) {
        index = (i + total) % total;
        track.style.transform = `translateX(-${index * 100}%)`;
        dots.forEach((d, di) => d.classList.toggle('active', di === index));
    }
    const next = () => go(index + 1);
    const prev = () => go(index - 1);
    const start = () => {
        stop();
        timer = setInterval(next, INTERVAL);
    };
    const stop = () => {
        if (timer) clearInterval(timer);
    };

    $('#carNext').addEventListener('click', () => {
        next();
        start();
    });
    $('#carPrev').addEventListener('click', () => {
        prev();
        start();
    });
    dots.forEach((d, i) => d.addEventListener('click', () => {
        go(i);
        start();
    }));

    const carousel = $('#home');
    carousel.addEventListener('mouseenter', stop);
    carousel.addEventListener('mouseleave', start);
    document.addEventListener('visibilitychange', () => document.hidden ? stop() : start());

    let startX = 0,
        dx = 0;
    track.addEventListener('touchstart', (e) => {
        startX = e.touches[0].clientX;
        dx = 0;
        stop();
    }, {
        passive: true
    });
    track.addEventListener('touchmove', (e) => {
        dx = e.touches[0].clientX - startX;
    }, {
        passive: true
    });
    track.addEventListener('touchend', () => {
        if (Math.abs(dx) > 50)(dx < 0 ? next() : prev());
        start();
    });

    go(0);
    start();
}

/* ============================================================
   UID verification flow  (landing only)
   ============================================================ */
function initUidFlow() {
    const uidForm = $('#uidForm');
    if (!uidForm) return;

    const uidInput = $('#uidInput');
    const uidHint = $('#uidHint');
    const verifyBtn = $('#verifyBtn');
    const modalOverlay = $('#modalOverlay');

    const setLoading = (on) => {
        verifyBtn.disabled = on;
        $('.btn-label', verifyBtn).textContent = on ? 'Verifying…' : 'Verify UID';
        $('.spinner', verifyBtn).hidden = !on;
    };

    const showWarning = (msg) => {
        $('.input-wrap').classList.add('invalid');
        uidHint.classList.add('error');
        uidHint.textContent = msg;
    };
    const clearWarning = () => {
        $('.input-wrap').classList.remove('invalid');
        uidHint.classList.remove('error');
        uidHint.textContent = 'Your UID is shown on your in-game profile.';
    };

    uidInput.addEventListener('input', () => {
        uidInput.value = uidInput.value.replace(/\D/g, '');
        clearWarning();
    });

    uidForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const uid = uidInput.value.trim();
        if (!/^\d{6,12}$/.test(uid)) {
            showWarning('Please enter a valid UID (6–12 digits).');
            return;
        }

        setLoading(true);
        clearWarning();
        try {
            const player = await fetchPlayerInfo(uid);
            state.player = player;
            savePlayer(player); // persist for the store page
            showPlayerModal(player);
        } catch (err) {
            showWarning(err.message || 'Could not verify UID.');
        } finally {
            setLoading(false);
        }
    });

    function setRow(rowSel, valSel, value) {
        const row = $(rowSel);
        if (value === null || value === undefined || value === '') {
            row.hidden = true;
            return;
        }
        row.hidden = false;
        $(valSel).textContent = value;
    }

    function showPlayerModal(p) {
        $('#pNick').textContent = p.nickname;
        $('#pUid').textContent = p.uid;
        $('#pLevel').textContent = p.level;
        $('#pRegion').textContent = p.region;
        $('#pLikes').textContent = p.likes != null ? p.likes.toLocaleString('en-IN') : '—';
        setRow('#rowClan', '#pClan', p.clan);
        $('#pSub').innerHTML = p.elitePass ?
            '🎉 Congratulations — <b style="color:var(--brand-2)">Elite Pass ✨</b> holder!' :
            '🎉 Congratulations — your account is ready!';
        openModal(modalOverlay);
        premiumEmoji($('#playerModal'));
        launchConfetti();
    }

    $('#modalClose').addEventListener('click', () => closeModal(modalOverlay));
    $('#notMeBtn').addEventListener('click', () => {
        closeModal(modalOverlay);
        state.player = null;
        clearPlayer();
        uidInput.value = '';
        uidInput.focus();
    });
    // Proceed → go to the separate store page
    $('#proceedBtn').addEventListener('click', () => {
        window.location.href = 'store.php';
    });
}

function launchConfetti() {
    const box = $('#confetti');
    if (!box) return;
    box.innerHTML = '';
    const colors = ['#ff7a18', '#ff3d3d', '#7b5cff', '#22d3ee', '#22c55e', '#ffd700'];
    for (let i = 0; i < 60; i++) {
        const c = document.createElement('i');
        c.style.left = Math.random() * 100 + '%';
        c.style.background = colors[i % colors.length];
        c.style.animationDuration = 1.5 + Math.random() * 1.5 + 's';
        c.style.animationDelay = Math.random() * 0.4 + 's';
        c.style.transform = `rotate(${Math.random() * 360}deg)`;
        box.appendChild(c);
    }
}

/* ============================================================
   Store  (store page only — guarded by UID verification)
   ============================================================ */
const API_BASE = 'api/';

/** Fallback catalogue labels when the API is unreachable (demo mode). */
const FALLBACK_CATS = [{
        slug: 'diamonds',
        name: 'Diamonds',
        icon: '💎'
    },
    {
        slug: 'passes',
        name: 'Passes',
        icon: '🎟️'
    },
    {
        slug: 'membership',
        name: 'Membership',
        icon: '👑'
    },
    {
        slug: 'special',
        name: 'Special',
        icon: '✨'
    },
];

/** Full-screen blocker shown when the site's access has expired. */
function showServiceUnavailable() {
    document.body.innerHTML =
        '<div style="min-height:100vh;display:flex;align-items:center;justify-content:center;text-align:center;padding:2rem;font-family:Inter,system-ui,sans-serif">' +
        '<div>' +
        '<div style="font-size:3rem;margin-bottom:.5rem">⌛</div>' +
        '<h1 style="margin:.2rem 0;font-size:1.4rem">Service unavailable</h1>' +
        '<p style="color:#888;max-width:24rem">This service is temporarily unavailable. Please check back later.</p>' +
        '</div>' +
        '</div>';
}

async function loadCatalogue() {
    try {
        const res = await fetch(API_BASE + 'products.php', {
            cache: 'no-store'
        });
        const data = await res.json();
        if (data && data.expired) return {
            categories: [],
            demo: false,
            expired: true
        };
        if (data && data.ok && Array.isArray(data.categories) && data.categories.length) {
            return {
                categories: data.categories,
                demo: false
            };
        }
        throw new Error('empty');
    } catch (_) {
        // Demo fallback to the static data.js catalogue
        const cats = FALLBACK_CATS
            .filter(c => window.PRODUCTS && window.PRODUCTS[c.slug])
            .map(c => ({ ...c,
                items: window.PRODUCTS[c.slug]
            }));
        return {
            categories: cats,
            demo: true
        };
    }
}

async function initStore() {
    const grid = $('#productGrid');
    if (!grid) return;

    // Gate: no verified player → kick back to landing.
    if (!state.player) {
        window.location.replace('index.php');
        return;
    }

    const player = state.player;
    if ($('#vNick')) $('#vNick').textContent = player.nickname;
    if ($('#vUid')) $('#vUid').textContent = player.uid;
    if ($('#vLevel')) $('#vLevel').textContent = `Lvl ${player.level}`;

    $('#changeAccount') ?.addEventListener('click', (e) => {
        e.preventDefault();
        clearPlayer();
        window.location.href = 'index.php';
    });

    const {
        categories,
        demo,
        expired
    } = await loadCatalogue();
    if (expired) {
        showServiceUnavailable();
        return;
    }
    state.demo = demo;
    const catMap = {};
    categories.forEach(c => {
        catMap[c.slug] = c.items || [];
    });

    // Build tabs dynamically (admin-defined categories)
    const tabsWrap = $('#tabs');
    tabsWrap.innerHTML = categories.map((c, i) =>
        `<button class="tab ${i === 0 ? 'active' : ''}" data-cat="${c.slug}">` +
        `${c.image ? `<img class="tab-ic" src="${esc(c.image)}" alt="">` : c.icon} ${esc(c.name)}</button>`
    ).join('');
    premiumEmoji(tabsWrap);

    const findProductLocal = (id) =>
        Object.values(catMap).flat().find(p => p.id === id);

    function renderProducts(slug) {
        const items = catMap[slug] || [];
        grid.innerHTML = items.map((p, i) => {
            const stock = Math.max(0, Number(p.stock ?? 0));
      const out = stock <= 0 || p.inStock === false;
            const stockLine = out ?
                `<span class="p-stock out">Out of stock</span>` :
                `<span class="p-stock${stock <= 10 ? ' low' : ''}">${stock} in stock</span>`;
            return `
      <article class="product${out ? ' is-out' : ''}" data-id="${p.id}" style="animation-delay:${i * 60}ms">
        ${out ? '<span class="out-badge">Out of stock</span>' : (p.tag ? `<span class="tag ${p.tag}">${p.tag === 'best' ? 'Best value' : 'Hot'}</span>` : '')}
        <div class="p-icon">${p.image ? `<img class="p-img" src="${esc(p.image)}?v=${encodeURIComponent(String(p.updated_at||p.image))}" alt="" loading="lazy">` : p.icon}</div>
        <div class="p-amount">${p.amount}</div>
        <div class="p-name">${p.name}</div>
        <div class="p-sub">${p.sub}</div>
        ${stockLine}
        <div class="p-foot">
          <div class="p-price">${money(p.price)}${p.old ? `<span class="p-old">${money(p.old)}</span>` : ''}</div>
          <span class="p-buy">${out ? 'Sold out' : 'Buy →'}</span>
        </div>
      </article>`;
        }).join('') || '<p class="muted center">No products in this category yet.</p>';
        $$('.product', grid).forEach(el => el.addEventListener('click', () => {
            const prod = findProductLocal(el.dataset.id);
            if (!prod || prod.inStock === false) {
                toast('This item is out of stock.', 'err');
                return;
            }
            startPayment(prod);
        }));
        premiumEmoji(grid);
    }

    tabsWrap.addEventListener('click', (e) => {
        const tab = e.target.closest('.tab');
        if (!tab) return;
        $$('.tab', tabsWrap).forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        renderProducts(tab.dataset.cat);
    });

    renderProducts(categories[0] ?.slug);
    initPayModal(player);
}

/* ============================================================
   🔥 PAYMENT FLOW WITH DISCOUNT 🔥
   ============================================================ */

// ============================================================
// 🔥 HAR PRODUCT KA ALAG DISCOUNT 🔥
// ============================================================
const DISCOUNTS = {
    'p1': 5,
    'p2': 10,
    'p3': 12,
    'p4': 15,
    'p5': 18,
    'p7': 8,
    'p8': 10,
    'p16': 7,
    'p17': 12
};

let payCtx = null; // { poll, countdown }

function initPayModal(player) {
    const overlay = $('#payOverlay');
    $('#payClose') ?.addEventListener('click', () => closePayment());
    overlay ?.addEventListener('click', (e) => {
        if (e.target === overlay) closePayment();
    });

    // expose to product click handler
    window.startPayment = (product) => {
        if (!product) return;

        // Demo mode (no PHP backend) — explain instead of failing
        if (state.demo) {
            openModal(overlay);
            $('#payBody').innerHTML = `
        <h3 class="modal-title">Demo mode</h3>
        <p class="modal-sub">The PHP backend isn't running, so live payment can't be created.</p>
        <div class="checkout-summary">
          <div class="cs-row"><span>Account</span><strong>${esc(player.nickname)}</strong></div>
          <div class="cs-row"><span>Item</span><strong>${esc(product.icon)} ${esc(product.name)}</strong></div>
          <div class="cs-row total"><span>Total</span><span class="grad">${money(product.price)}</span></div>
        </div>
        <p class="muted center">Run the site on PHP + complete <code>install.php</code> to enable real UPI payments.</p>`;
            premiumEmoji($('#payBody'));
            return;
        }
        showConfirm(product, player);
    };
}

/** Default promo auto-applied for every customer. */
const DEFAULT_PROMO = 'WELCOME10';

/** Step 1 — confirm order with discount. */
function showConfirm(product, player) {
    const overlay = $('#payOverlay');
    let applied = null;
    openModal(overlay);

    const render = () => {
        const total = applied ? applied.final : product.price;
        const discountPercent = DISCOUNTS[product.id] || 0;
        const discountAmount = applied ? applied.discount : 0;

        $('#payBody').innerHTML = `
      <h3 class="modal-title">Confirm order</h3>
      <p class="modal-sub">Review your top-up before paying.</p>
      
      ${discountPercent > 0 ? `
        <div style="background:#dcfce7;color:#16a34a;padding:10px 16px;border-radius:10px;margin-bottom:16px;text-align:center;font-weight:600;">
          🎉 ${discountPercent}% OFF on ${esc(product.name)}!
          ${discountAmount > 0 ? `You save ₹${discountAmount.toFixed(2)}` : ''}
        </div>
      ` : ''}
      
      <div class="checkout-summary">
        <div class="cs-row"><span>Account</span><strong>${esc(player.nickname)}</strong></div>
        <div class="cs-row"><span>UID</span><strong>${esc(player.uid)}</strong></div>
        <div class="cs-row"><span>Item</span><strong>${product.image ? '' : esc(product.icon) + ' '}${esc(product.name)}</strong></div>
        ${applied ? `<div class="cs-row"><span>Promo (${esc(applied.code)})</span><strong style="color:var(--good)">– ₹${applied.discount.toFixed(2)}</strong></div>` : ''}
        <div class="cs-row total">
          <span>Total</span>
          <span class="grad">
            ${discountPercent > 0 ? `<span style="text-decoration:line-through;color:#94a3b8;font-size:14px;margin-right:8px;">₹${product.price.toFixed(2)}</span>` : ''}
            ₹${total.toFixed(2)}
          </span>
        </div>
      </div>
      ${applied ? `<div class="promo-applied">🎉 Promo <b>${esc(applied.code)}</b> applied — you saved ₹${applied.discount.toFixed(2)}!</div>` : ''}
      <button class="btn btn-primary btn-block" id="toPayBtn">Proceed to Pay →</button>
      <button class="btn btn-text" onclick="closePayment()">Cancel</button>`;
        premiumEmoji($('#payBody'));
        $('#toPayBtn').addEventListener('click', () => createAndShow(product, player, applied ? applied.code : ''));
    };

    // Auto-apply discount
    const discountPercent = DISCOUNTS[product.id] || 0;
    if (discountPercent > 0) {
        const discountAmount = (product.price * discountPercent) / 100;
        const finalAmount = product.price - discountAmount;
        applied = {
            discount: discountAmount,
            final: finalAmount,
            code: 'WELCOME10',
            percent: discountPercent
        };
        render();
    } else {
        render();
    }
}

/** Step 2 — create the order and show the QR. */
async function createAndShow(product, player, coupon) {
    $('#payBody').innerHTML = `<div class="pay-loading"><span class="spinner big"></span><p>Creating secure payment…</p></div>`;
    try {
        const r = await fetch(`${API_BASE}create_order.php`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            cache: 'no-store',
            body: JSON.stringify({
                product_id: product.id,
                uid: player.uid,
                nickname: player.nickname,
                level: player.level,
                coupon: coupon || ''
            })
        });
        const order = await r.json();
        if (!r.ok || !order.ok) throw new Error(order.error || 'Could not create order.');
        // Server is authoritative: one stock unit has now been reserved.
        if (order.product && typeof order.product.stock !== 'undefined') {
          product.stock = Number(order.product.stock);
          product.inStock = product.stock > 0;
          product.updated_at = order.product.updated_at || Date.now();
          const card = document.querySelector(`.product[data-id=\"${CSS.escape(String(product.id))}\"]`);
          if (card) {
            const stockEl = card.querySelector('.p-stock');
            const buyEl = card.querySelector('.p-buy');
            if (stockEl) {
              stockEl.textContent = product.stock > 0 ? `${product.stock} in stock` : 'Out of stock';
              stockEl.classList.toggle('out', product.stock <= 0);
              stockEl.classList.toggle('low', product.stock > 0 && product.stock <= 10);
            }
            if (buyEl) buyEl.textContent = product.stock > 0 ? 'Buy →' : 'Sold out';
            card.classList.toggle('is-out', product.stock <= 0);
          }
        }
        showQr(order, product, player);
    } catch (err) {
        $('#payBody').innerHTML = `
      <div class="success-ring err"><span class="check">!</span></div>
      <h3 class="modal-title">Something went wrong</h3>
      <p class="modal-sub">${esc(err.message)}</p>
      <button class="btn btn-ghost btn-block" onclick="closePayment()">Close</button>`;
    }
}
function showQr(order, product, player) {
    const discountPercent = DISCOUNTS[product.id] || 0;

    $('#payBody').innerHTML = `
    <h3 class="modal-title">Scan & Pay</h3>
    <p class="modal-sub">Pay the <b>exact amount</b>, then tap "I have paid".</p>
    ${discountPercent > 0 ? `
      <div style="background:#dcfce7;color:#16a34a;padding:8px 12px;border-radius:8px;margin-bottom:12px;text-align:center;font-weight:600;font-size:14px;">
        🎉 ${discountPercent}% OFF applied! You saved ₹${order.discount.toFixed(2)}
      </div>
    ` : ''}
    <div class="qr-box">
      <img id="qrImg" src="${esc(order.qr)}" alt="UPI QR" width="220" height="220" />
    </div>
    <div class="pay-amount">
      ${discountPercent > 0 ? `<span style="text-decoration:line-through;color:#94a3b8;font-size:18px;margin-right:8px;">₹${product.price.toFixed(2)}</span>` : ''}
      ${money(order.amount)}
    </div>
    <div class="checkout-summary">
      <div class="cs-row"><span>Account</span><strong>${esc(player.nickname)}</strong></div>
      <div class="cs-row"><span>UID</span><strong>${esc(player.uid)}</strong></div>
      <div class="cs-row"><span>Item</span><strong>${esc(product.icon)} ${esc(product.name)}</strong></div>
      <div class="cs-row"><span>Order</span><strong>${esc(order.order_code)}</strong></div>
    </div>
    <div class="pay-notice" id="payNotice" hidden></div>
    <button class="btn btn-primary btn-block" id="iPaidBtn">✓ I have paid</button>
    <button class="btn btn-ghost btn-block" id="dlQrBtn">⬇ Download QR</button>
    <div class="pay-status">QR valid for <span id="payTimer"></span></div>
    <button class="btn btn-text" onclick="closePayment()">Cancel</button>`;
    premiumEmoji($('#payBody'));

    const qrImg = $('#qrImg');
    if (qrImg) {
        qrImg.addEventListener('error', () => {
            const box = qrImg.closest('.qr-box');
            if (box) box.innerHTML =
                '<div style="padding:22px 16px;text-align:center;font-size:.85rem;color:#333;line-height:1.5">' +
                'QR couldn\'t load on this network.<br>Tap <b>"Download QR"</b> below and<br>scan it from your gallery.</div>';
        });
    }

    $('#iPaidBtn').addEventListener('click', () => verifyNow(order, product, player));
    $('#dlQrBtn').addEventListener('click', () => downloadQr(order.qr, order.order_code));

    let remaining = order.expires_in || 900;
    const tick = () => {
        remaining--;
        const m = Math.floor(remaining / 60),
            s = String(remaining % 60).padStart(2, '0');
        const t = $('#payTimer');
        if (t) t.textContent = `${m}:${s}`;
        if (remaining <= 0) paymentExpired();
    };
    tick();
    clearPayTimers();
    payCtx = {
        countdown: setInterval(tick, 1000),
        poll: null
    };
}

/** Download the QR image (fetches the PNG and saves it; falls back to opening it). */
async function downloadQr(url, code) {
    const filename = `firetopup-qr-${code || 'payment'}.png`;
    try {
        const res = await fetch(url, {
            cache: 'no-store'
        });
        const blob = await res.blob();
        const obj = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = obj;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(obj), 2000);
    } catch (_) {
        window.open(url, '_blank', 'noopener');
    }
}

/** Check payment when the user taps "I have paid". */
async function verifyNow(order, product, player) {
    const body = $('#payBody');
    if (!body) return;
    body.innerHTML = `
      <div class="utr-head-icon"><span>✓</span></div>
      <h3 class="modal-title">Payment confirmation</h3>
      <p class="modal-sub">Enter the <b>12-digit UTR</b> from your UPI payment.</p>
      <div class="checkout-summary utr-summary">
        <div class="cs-row"><span>Order</span><strong>${esc(order.order_code)}</strong></div>
        <div class="cs-row"><span>Amount</span><strong>${money(order.amount)}</strong></div>
      </div>
      <div class="utr-field">
        <label for="utrInput">12-DIGIT UTR</label>
        <div class="utr-input-wrap"><span>№</span><input id="utrInput" class="utr-input" inputmode="numeric" autocomplete="off" maxlength="12" placeholder="Enter 12-digit UTR" /></div>
        <div class="utr-count" id="utrCount">0 / 12 digits</div>
      </div>
      <div class="utr-confirm-field" id="utrConfirmField" hidden>
        <label for="utrConfirm">CONFIRM UTR</label>
        <div class="utr-input-wrap"><span>✓</span><input id="utrConfirm" class="utr-input" inputmode="numeric" autocomplete="off" maxlength="12" placeholder="Enter the same UTR again" /></div>
        <div class="utr-match" id="utrMatch">Re-enter the same 12 digits</div>
      </div>
      <div class="pay-notice" id="payNotice" hidden></div>
      <button class="btn btn-primary btn-block utr-submit" id="submitUtr" disabled>✓ Submit UTR</button>
      <p class="utr-help">Your payment claim will be sent to the admin for verification.</p>
      <button class="btn btn-text" onclick="closePayment()">Cancel</button>`;

    const first = $('#utrInput'), second = $('#utrConfirm'), confirmBox = $('#utrConfirmField');
    const count = $('#utrCount'), match = $('#utrMatch'), submit = $('#submitUtr');
    const digits = el => (el.value || '').replace(/\D/g,'').slice(0,12);
    const update = () => {
      first.value = digits(first); second.value = digits(second);
      const a = first.value, b = second.value;
      count.textContent = `${a.length} / 12 digits`;
      confirmBox.hidden = a.length < 12;
      if (a.length < 12) { second.value=''; match.textContent='Enter the first UTR completely'; match.className='utr-match'; }
      else if (!b) { match.textContent='Now enter the same UTR again'; match.className='utr-match'; }
      else if (a === b) { match.textContent='✓ UTRs match'; match.className='utr-match good'; }
      else { match.textContent='UTRs do not match'; match.className='utr-match bad'; }
      submit.disabled = !(a.length === 12 && b.length === 12 && a === b);
    };
    first.addEventListener('input', update); second.addEventListener('input', update); first.focus();

    submit.addEventListener('click', async () => {
      const u1 = first.value, u2 = second.value;
      if (submit.disabled) return;
      submit.disabled = true; submit.innerHTML = '<span class="spinner"></span> Submitting…';
      try {
        const r = await fetch(`${API_BASE}claim_utr.php`, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({order_code:order.order_code,utr:u1,utr_confirm:u2}), cache:'no-store'});
        const d = await r.json();
        if (d.ok) {
          clearPayTimers();
          body.innerHTML = `<div class="success-ring"><span class="check">✓</span></div><h3 class="modal-title">UTR submitted</h3><p class="modal-sub">Your payment claim has been sent for verification.</p><div class="checkout-summary"><div class="cs-row"><span>Order</span><strong>${esc(order.order_code)}</strong></div><div class="cs-row"><span>UTR</span><strong>${esc(u1)}</strong></div></div><p class="muted center">The admin will verify the payment and update your order status.</p><a class="btn btn-primary btn-block" href="track.php?code=${encodeURIComponent(order.order_code)}">📦 Track my order</a><button class="btn btn-text" onclick="closePayment()">Done</button>`;
        } else { showPayNotice(d.error || 'Could not submit UTR.'); update(); submit.innerHTML='✓ Submit UTR'; }
      } catch(e) { showPayNotice('Could not submit right now. Check your connection.'); update(); submit.innerHTML='✓ Submit UTR'; }
    });
}
function showPayNotice(msg) {
    const n = $('#payNotice');
    if (!n) return;
    n.textContent = msg;
    n.hidden = false;
    n.classList.remove('shake');
    void n.offsetWidth;
    n.classList.add('shake');
}

function paymentSuccess(order, product, player) {
    clearPayTimers();
    launchConfettiInto($('#payBody'));
    const trackUrl = `track.php?code=${encodeURIComponent(order.order_code)}`;
    const waText = encodeURIComponent(
        `✅ Order ${order.order_code}\n${product.name} for UID ${player.uid} (${player.nickname})\nTrack: ${location.origin}${location.pathname.replace(/store\.php$/, '')}${trackUrl}`
    );
    $('#payBody').innerHTML = `
    <div class="success-ring"><span class="check">✓</span></div>
    <h3 class="modal-title">🎉 Payment received!</h3>
    <p class="modal-sub">Your order is confirmed.</p>
    <div class="checkout-summary">
      <div class="cs-row"><span>Item</span><strong>${esc(product.icon)} ${esc(product.name)}</strong></div>
      <div class="cs-row"><span>Delivering to</span><strong>${esc(player.nickname)} (${esc(player.uid)})</strong></div>
      <div class="cs-row"><span>Order</span><strong>${esc(order.order_code)}</strong></div>
    </div>
    <p class="muted center">Save your order code to track delivery.</p>
    <a class="btn btn-primary btn-block" href="${trackUrl}">📦 Track my order</a>
    <a class="btn btn-ghost btn-block" href="https://wa.me/?text=${waText}" target="_blank" rel="noopener">Share receipt on WhatsApp</a>
    <button class="btn btn-text" onclick="closePayment()">Done</button>`;
    premiumEmoji($('#payBody'));
}

function paymentExpired() {
    clearPayTimers();
    $('#payBody').innerHTML = `
    <div class="success-ring err"><span class="check">⌛</span></div>
    <h3 class="modal-title">Session expired</h3>
    <p class="modal-sub">This payment window timed out. Please start again.</p>
    <button class="btn btn-primary btn-block" onclick="closePayment()">Close</button>`;
    premiumEmoji($('#payBody'));
}

function clearPayTimers() {
    if (payCtx) {
        clearInterval(payCtx.poll);
        clearInterval(payCtx.countdown);
        payCtx = null;
    }
}

function closePayment() {
    clearPayTimers();
    closeModal($('#payOverlay'));
}

function esc(s) {
    return String(s).replace(/[&<>"']/g, c => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
    }[c]));
}

function launchConfettiInto(container) {
    const box = document.createElement('div');
    box.className = 'confetti';
    container.prepend(box);
    const colors = ['#ff7a18', '#ff3d3d', '#7b5cff', '#22d3ee', '#22c55e', '#ffd700'];
    for (let i = 0; i < 50; i++) {
        const c = document.createElement('i');
        c.style.left = Math.random() * 100 + '%';
        c.style.background = colors[i % colors.length];
        c.style.animationDuration = 1.5 + Math.random() * 1.5 + 's';
        c.style.animationDelay = Math.random() * 0.3 + 's';
        box.appendChild(c);
    }
}

/* ============================================================
   FAQ accordion
   ============================================================ */
function initFaq() {
    $$('.acc-q').forEach(q =>
        q.addEventListener('click', () => {
            const item = q.parentElement;
            const open = item.classList.contains('open');
            $$('.acc-item').forEach(i => {
                i.classList.remove('open');
                $('.acc-a', i).style.maxHeight = null;
            });
            if (!open) {
                item.classList.add('open');
                $('.acc-a', item).style.maxHeight = $('.acc-a', item).scrollHeight + 'px';
            }
        })
    );
}

/* ============================================================
   Init (runs on every page; each module guards itself)
   ============================================================ */
function init() {
    initTheme();
    initNav();
    initModals();
    initCarousel();
    initUidFlow();
    initStore();
    initFaq();
    initSalePops();
    initReveal();
    premiumEmoji();
    const y = $('#year');
    if (y) y.textContent = new Date().getFullYear();
}
init();