FFMAXWEB BACKEND SETUP

1. Upload the complete folder to PHP hosting (PHP 8.0+ recommended).
2. Make sure the /data directory is writable by PHP.
3. The admin configuration is stored in /admin/data/config.json. No installer is required.
4. Open /admin/ and immediately change the default admin password.
5. Set your merchant UPI and merchant name in Admin > Merchant settings.
6. Delete or rename install.php after setup.

Payment note:
The site generates a UPI intent/QR and records orders server-side. check_payment.php only reports the server-side order status. It does NOT claim automatic bank verification. Mark an order paid in the admin panel only after confirming the payment through your legitimate payment provider/bank records.
