<?php
require __DIR__.'/../config.php';
try {
    $code=clean((string)($_GET['order_code']??''),50);
    $lockPath = STORE_FILE . '.lock';
    $lock = @fopen($lockPath, 'c');
    if (!$lock || !flock($lock, LOCK_EX)) {
        if (is_resource($lock)) @fclose($lock);
        json_response(['ok'=>false,'error'=>'Store is temporarily busy'],503);
    }
    @chmod($lockPath,0600);
    try {
        $d=store_load(); $o=null; $idx=null;
        foreach (($d['orders']??[]) as $i=>$x) if (($x['order_code']??'')===$code) { $idx=$i; $o=$x; break; }
        if ($o===null) { flock($lock,LOCK_UN); fclose($lock); json_response(['ok'=>false,'error'=>'Order not found'],404); }
        if (($o['status']??'')==='pending' && time()>=(int)($o['expires_at']??0)) {
            // Release the reserved stock exactly once for an expired pending order.
            if (!empty($o['stock_reserved'])) {
                foreach (($d['products']??[]) as $ci=>$cat) {
                    foreach (($cat['items']??[]) as $pi=>$p) {
                        if ((string)($p['id']??'') === (string)($o['product_id']??'')) {
                            $newStock=max(0,(int)($p['stock']??0)+1);
                            $d['products'][$ci]['items'][$pi]['stock']=$newStock;
                            $d['products'][$ci]['items'][$pi]['inStock']=$newStock>0;
                            $d['products'][$ci]['items'][$pi]['updated_at']=time();
                            break 2;
                        }
                    }
                }
                $d['orders'][$idx]['stock_reserved']=0;
            }
            $d['orders'][$idx]['status']='expired';
            $d['orders'][$idx]['updated_at']=time();
            store_save($d); $o=$d['orders'][$idx];
        }
        flock($lock,LOCK_UN); fclose($lock);
        json_response(['ok'=>true,'status'=>$o['status']??'pending','order_code'=>$o['order_code'],'delivery_status'=>$o['delivery_status']??'pending','utr_submitted'=>!empty($o['utr'])]);
    } catch (Throwable $e) {
        if (is_resource($lock)) { @flock($lock,LOCK_UN); @fclose($lock); }
        throw $e;
    }
} catch(Throwable $e) { json_response(['ok'=>false,'error'=>'Server error'],500); }
