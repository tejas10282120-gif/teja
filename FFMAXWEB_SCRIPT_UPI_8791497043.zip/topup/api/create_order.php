<?php
require __DIR__.'/../config.php';

try {
    $req = input_json();
    $pid = clean((string)($req['product_id'] ?? ''), 50);
    $uid = clean((string)($req['uid'] ?? ''), 20);
    $nick = clean((string)($req['nickname'] ?? ''), 80);
    $level = clean((string)($req['level'] ?? ''), 20);
    $coupon = clean((string)($req['coupon'] ?? ''), 40);

    if (!preg_match('/^\d{6,12}$/', $uid) || $nick === '' || $pid === '') {
        json_response(['ok'=>false,'error'=>'Invalid order data.'], 400);
    }

    // Lock the store for the entire read -> stock check -> reserve -> save cycle.
    // This prevents two simultaneous orders from consuming the same stock.
    $lockPath = STORE_FILE . '.lock';
    $lock = @fopen($lockPath, 'c');
    if (!$lock || !flock($lock, LOCK_EX)) {
        if (is_resource($lock)) @fclose($lock);
        json_response(['ok'=>false,'error'=>'Store is temporarily busy. Please try again.'], 503);
    }
    @chmod($lockPath, 0600);

    try {
        // IMPORTANT: products.php is an HTTP endpoint, not JSON. Read the same
        // server-side catalogue used by the public catalogue endpoint.
        $store = store_load();
        $product = null;
        $productCategory = null;
        $productIndex = null;
        foreach (($store['products'] ?? []) as $ci => $cat) {
            foreach (($cat['items'] ?? []) as $pi => $item) {
                if ((string)($item['id'] ?? '') === $pid) {
                    $product = $item;
                    $productCategory = $ci;
                    $productIndex = $pi;
                    break 2;
                }
            }
        }

        if (!$product) {
            flock($lock, LOCK_UN); fclose($lock);
            json_response(['ok'=>false,'error'=>'Product not found. Please refresh the store and try again.'], 404);
        }

        $stock = max(0, (int)($product['stock'] ?? 0));
        if ($stock <= 0 || ($product['inStock'] ?? true) === false) {
            flock($lock, LOCK_UN); fclose($lock);
            json_response(['ok'=>false,'error'=>'This product is sold out.'], 409);
        }

        $price = max(0, (float)($product['price'] ?? 0));
        // Discount keys MUST match the actual product IDs in store.json.
        $discounts = [
            'p1'=>5, 'p2'=>10, 'p3'=>12, 'p4'=>15,
            'p5'=>18, 'p7'=>8, 'p8'=>10, 'p16'=>7, 'p17'=>12
        ];
        $pct = (float)($discounts[$pid] ?? 0);
        $discount = round($price * $pct / 100, 2);
        $amount = round($price - $discount, 2);

        $code = 'FT'.date('ymd').strtoupper(substr(bin2hex(random_bytes(4)), 0, 6));
        $txn = 'FTX'.date('YmdHis').random_int(100,999);
        $cfg = secure_load();
        $upi = $cfg['merchant_upi'] ?? DEFAULT_MERCHANT_UPI;
        $merchant = $cfg['merchant_name'] ?? DEFAULT_MERCHANT_NAME;
        $upiUrl = 'upi://pay?pa='.rawurlencode($upi)
            .'&pn='.rawurlencode($merchant)
            .'&am='.number_format($amount,2,'.','')
            .'&cu=INR&tr='.rawurlencode($txn)
            .'&tn='.rawurlencode((string)$product['name']);

        $now = time();
        if (!isset($store['orders']) || !is_array($store['orders'])) $store['orders'] = [];
        $maxId = 0;
        foreach ($store['orders'] as $oldOrder) $maxId = max($maxId, (int)($oldOrder['id'] ?? 0));

        // Reserve one unit immediately. It is returned if the pending order expires.
        $store['products'][$productCategory]['items'][$productIndex]['stock'] = $stock - 1;
        $store['products'][$productCategory]['items'][$productIndex]['inStock'] = ($stock - 1) > 0;
        $store['products'][$productCategory]['items'][$productIndex]['updated_at'] = $now;
        $product['stock'] = $stock - 1;
        $product['inStock'] = ($stock - 1) > 0;
        $product['updated_at'] = $now;

        $store['orders'][] = [
            'id'=>$maxId+1,
            'order_code'=>$code,
            'txn'=>$txn,
            'product_id'=>$pid,
            'product_name'=>(string)$product['name'],
            'amount'=>$amount,
            'discount'=>$discount,
            'coupon'=>$coupon ?: null,
            'uid'=>$uid,
            'nickname'=>$nick,
            'level'=>$level,
            'upi'=>$upiUrl,
            'status'=>'pending',
            'delivery_status'=>'pending',
            'created_at'=>$now,
            'expires_at'=>$now+ORDER_TTL,
            'paid_at'=>null,
            'utr'=>null,
            'utr_submitted_at'=>null,
            'stock_reserved'=>1,
            'updated_at'=>$now
        ];
        store_save($store);
        flock($lock, LOCK_UN); fclose($lock);

        json_response([
            'ok'=>true,
            'order_code'=>$code,
            'txn'=>$txn,
            'amount'=>$amount,
            'amount_str'=>number_format($amount,2,'.',''),
            'discount'=>$discount,
            'coupon'=>$coupon ?: null,
            'upi'=>$upiUrl,
            'qr'=>'api/qr.php?s=280&d='.rawurlencode($upiUrl),
            'expires_in'=>ORDER_TTL,
            'product'=>$product
        ]);
    } catch (Throwable $e) {
        if (is_resource($lock)) { @flock($lock, LOCK_UN); @fclose($lock); }
        throw $e;
    }
} catch (Throwable $e) {
    json_response(['ok'=>false,'error'=>'Server error while creating the order.'], 500);
}
