<?php
// QR renderer. Uses QuickChart as the renderer; no payment credentials are sent.
$d=(string)($_GET['d'] ?? '');
$size=max(120,min(1000,(int)($_GET['s'] ?? 280)));
if($d===''){http_response_code(400);header('Content-Type:text/plain');exit('Missing QR data');}
$url='https://quickchart.io/qr?size='.$size.'&text='.rawurlencode($d);
header('Cache-Control: no-store');
header('Location: '.$url, true, 302); exit;
